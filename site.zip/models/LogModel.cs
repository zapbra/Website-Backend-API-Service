﻿namespace WebApplication1.models
{
    public class LogModel
    {
        public string PagePath { get; set; }
        public string Message { get; set; }
    }
}
